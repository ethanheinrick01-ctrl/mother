window.FILMS=[
  {
    "id": "e4-ch28",
    "ch": 28,
    "title": "Red cells: production, passage and recycling",
    "exam": 4,
    "duration": 61.944,
    "stages": [
      {
        "start": 0,
        "title": "Oxygen delivery",
        "text": "Red cells connect oxygen delivery to a regulated production response. Start with the circulating erythrocyte. Its reversible deformability permits passage through narrow vessels."
      },
      {
        "start": 11.06,
        "title": "Hypoxia to production",
        "text": "When oxygen availability falls, the kidney releases erythropoietin. The marrow responds by increasing red cell production. Reticulocytes are newly released cells, so they help us follow that response."
      },
      {
        "start": 23.14,
        "title": "Aging and recycling",
        "text": "Production is only half of the cycle. Macrophages remove aging erythrocytes, usually in the spleen. Globin is broken into amino acids, and the porphyrin portion of heme becomes bilirubin. Iron is recycled."
      },
      {
        "start": 36.08,
        "title": "Transport versus storage",
        "text": "Transferrin transports iron through plasma, while ferritin stores it within cells. Keep these roles separate: erythropoietin signals production, transferrin transports iron, and ferritin stores iron. The figure provides visual orientation. These tested relationships come from Chapter twenty eight, slides twelve, thirty eight, thirty nine, forty four, and forty five. The complete iron absorption pathway remains a textbook gap."
      }
    ],
    "sources": [
      "CH28S12",
      "CH28S38",
      "CH28S39",
      "CH28S44",
      "CH28S45"
    ],
    "logline": "Red cells: production, passage and recycling: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "Shaded biconcave red cells deform through a narrowed capillary and recover their shape.",
      "A kidney-to-marrow inset sends EPO; newly formed cells enter circulation.",
      "A macrophage engulfs an aging cell; iron remains available for recycling.",
      "Iron cargo travels on transferrin and is separately retained inside a ferritin shell."
    ],
    "audio": "e4-ch28.m4a",
    "figures": [
      {
        "title": "Hematopoietic cell lineages",
        "credit": "OpenStax, Anatomy and Physiology, version 8.25 (2016)",
        "url": "https://commons.wikimedia.org/wiki/File:0337_Hematopoiesis_new.jpg"
      },
      {
        "title": "Normal vessel repair and hemostasis",
        "credit": "OpenStax College, Anatomy and Physiology (2013), 1909 Blood Clotting; part (a) credit Kevin MacKenzie",
        "url": "https://commons.wikimedia.org/wiki/File:1909_Blood_Clotting.jpg"
      }
    ]
  },
  {
    "id": "e4-ch29",
    "ch": 29,
    "title": "DIC: clotting, consumption and bleeding",
    "exam": 4,
    "duration": 60.264,
    "stages": [
      {
        "start": 0,
        "title": "Local repair reference",
        "text": "Normal clotting confines fibrin formation to a vessel injury. This scholarly repair figure provides the reference. Disseminated intravascular coagulation changes the location and extent of that process."
      },
      {
        "start": 12.64,
        "title": "Widespread activation",
        "text": "In DIC, widespread tissue factor exposure activates clotting. Thrombin and fibrin activity increase. Fibrin deposits inside small vessels impede blood flow, reducing organ perfusion."
      },
      {
        "start": 24.28,
        "title": "Consumption and bleeding",
        "text": "As clotting continues, platelets and coagulation factors are consumed. Accelerated fibrinolysis accompanies the process. The same patient can therefore have microvascular thrombosis and uncontrolled bleeding."
      },
      {
        "start": 37.08,
        "title": "Treat the driver",
        "text": "Treatment goals include eliminating the underlying pathology, restoring hemostasis and supporting failing organs. Component replacement alone does not remove the trigger. Chapter twenty nine, slides one hundred seventeen through one hundred twenty, support this sequence. The complete diagnostic laboratory pattern and specific treatment indications remain textbook gaps."
      }
    ],
    "sources": [
      "CH29S117",
      "CH29S118",
      "CH29S119",
      "CH29S120"
    ],
    "logline": "DIC: clotting, consumption and bleeding: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A damaged capillary wall receives a localized platelet-and-fibrin repair.",
      "A separate DIC view develops fibrin webs at several microvascular sites; blood passage slows.",
      "Circulating platelets decrease while local bleeding appears at a wall defect.",
      "The causal scene holds with the trigger, hemostasis and organ-support targets clearly separated."
    ],
    "audio": "e4-ch29.m4a",
    "figures": [
      {
        "title": "Normal vessel repair and hemostasis",
        "credit": "OpenStax College, Anatomy and Physiology (2013), 1909 Blood Clotting; part (a) credit Kevin MacKenzie",
        "url": "https://commons.wikimedia.org/wiki/File:1909_Blood_Clotting.jpg"
      }
    ]
  },
  {
    "id": "e4-ch30",
    "ch": 30,
    "title": "Sickling: flexibility, flow and distinct crises",
    "exam": 4,
    "duration": 62.112,
    "stages": [
      {
        "start": 0,
        "title": "Flexible red cells",
        "text": "A red cell must deform to move through microcirculation. The normal cell and the sickle cell shown here are adapted from scholarly illustrations. The motion uses schematic time and scale."
      },
      {
        "start": 11.1,
        "title": "Stiffening and obstruction",
        "text": "In sickle cell disease, abnormal hemoglobin polymerization stiffens the cell. Hypoxia, dehydration and acidosis favor sickling in the packet. Stiff cells obstruct small vessels, causing pain and tissue injury."
      },
      {
        "start": 24.58,
        "title": "Different crisis mechanisms",
        "text": "Keep the crises distinct. Vasoocclusive crisis obstructs microcirculation. Aplastic crisis transiently stops production. Sequestration crisis pools blood in the spleen. Hyperhemolytic crisis increases red cell destruction."
      },
      {
        "start": 39.58,
        "title": "Mechanism guides the decision",
        "text": "The treatment slide links care to crisis prevention, pain and infection management, fluids and hydroxyurea. Supplemental oxygen is qualified by current hypoxia. Chapter thirty, slides twenty three, twenty four, twenty six, twenty seven and twenty nine, supply these claims. The contradictory amino acid substitution wording is excluded; definitive diagnostic testing remains missing."
      }
    ],
    "sources": [
      "CH30S23",
      "CH30S24",
      "CH30S26",
      "CH30S27",
      "CH30S29"
    ],
    "logline": "Sickling: flexibility, flow and distinct crises: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "Biconcave cells deform through a capillary neck.",
      "Intracellular fibers build, cells become rigid and curved, and the small vessel obstructs.",
      "Four separate vignettes compare obstruction, halted marrow output, splenic pooling and increased destruction.",
      "The mechanism comparison holds with source-supported care targets in the caption."
    ],
    "audio": "e4-ch30.m4a",
    "figures": [
      {
        "title": "Hematopoietic cell lineages",
        "credit": "OpenStax, Anatomy and Physiology, version 8.25 (2016)",
        "url": "https://commons.wikimedia.org/wiki/File:0337_Hematopoiesis_new.jpg"
      },
      {
        "title": "Normal vessel repair and hemostasis",
        "credit": "OpenStax College, Anatomy and Physiology (2013), 1909 Blood Clotting; part (a) credit Kevin MacKenzie",
        "url": "https://commons.wikimedia.org/wiki/File:1909_Blood_Clotting.jpg"
      },
      {
        "title": "Sickle erythrocyte",
        "credit": "Database Center for Life Science (DBCLS), Togo picture gallery (2024), DOI 10.7875/togopic.2024.219",
        "url": "https://commons.wikimedia.org/wiki/File:202410_Sckle_Cell.svg"
      }
    ]
  },
  {
    "id": "e4-ch31",
    "ch": 31,
    "title": "The cardiac cycle: filling, closed valves and ejection",
    "exam": 4,
    "duration": 61.56,
    "stages": [
      {
        "start": 0,
        "title": "Filling",
        "text": "Follow blood through the valves, using the original OpenStax heart as an anatomical reference. During passive ventricular filling, the atrioventricular valves are open and the semilunar valves are closed. Atrial systole completes filling."
      },
      {
        "start": 15,
        "title": "Pressure without ejection",
        "text": "The ventricles begin isovolumetric systole. Atrioventricular valves close, and all valves are briefly closed. Pressure rises while ventricular volume is unchanged."
      },
      {
        "start": 25.7,
        "title": "Ejection",
        "text": "When ventricular pressure exceeds outflow pressure, the semilunar valves open. The ventricles eject blood toward the pulmonary artery and aorta. The animation tracks movement rather than claiming a measured flow speed."
      },
      {
        "start": 38.64,
        "title": "Relaxation and refilling",
        "text": "Semilunar valves close during isovolumetric relaxation. All valves are again closed until ventricular pressure falls enough for atrioventricular opening and renewed filling. Chapter thirty one, slides fifteen, sixteen and twenty through twenty three, support this sequence. Numeric chamber pressures and complete abnormal tracing interpretation are not supplied."
      }
    ],
    "sources": [
      "CH31S15",
      "CH31S16",
      "CH31S20",
      "CH31S21",
      "CH31S22",
      "CH31S23"
    ],
    "logline": "The cardiac cycle: filling, closed valves and ejection: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A four-chamber cutaway fills through open atrioventricular valves; outflow valves stay closed.",
      "All valve leaflets meet; pressure increases with an unchanged ventricular blood volume.",
      "Outflow valves open and ventricular volume decreases as blood enters the aorta and pulmonary trunk.",
      "All valves close during relaxation, then atrioventricular valves reopen for filling."
    ],
    "audio": "e4-ch31.m4a",
    "figures": [
      {
        "title": "Internal anatomy of the heart",
        "credit": "OpenStax College, Anatomy and Physiology (2013)",
        "url": "https://commons.wikimedia.org/wiki/File:2008_Internal_Anatomy_of_the_HeartN.jpg"
      }
    ]
  },
  {
    "id": "e4-ch32",
    "ch": 32,
    "title": "Heart failure: contraction versus filling",
    "exam": 4,
    "duration": 66.432,
    "stages": [
      {
        "start": 0,
        "title": "Compare the mechanism",
        "text": "Heart failure is a supply problem with different mechanical routes. We use the same scholarly ventricular anatomy for both comparisons. The moving volume markers are schematic, not measured chamber volumes."
      },
      {
        "start": 12.3,
        "title": "Reduced ejection",
        "text": "In systolic failure, impaired contraction reduces ejection. More blood remains after the beat, and stroke volume falls. The chapter connects reduced output with activation of compensatory systems."
      },
      {
        "start": 24.52,
        "title": "Restricted filling",
        "text": "In diastolic failure, relaxation and compliance are abnormal. Filling is restricted even when ejection fraction is preserved. A preserved fraction does not guarantee that enough blood enters and leaves the ventricle."
      },
      {
        "start": 38,
        "title": "Locate congestion",
        "text": "The slides distinguish pulmonary congestion in left failure from systemic venous congestion in right failure. Orthopnea and pulmonary edema belong to the pulmonary side; jugular venous distension and peripheral edema identify systemic congestion. Chapter thirty two, slides eighty nine, ninety and ninety two through ninety five, support the comparison. Specific diagnostic cutoffs and treatment selection require additional textbook evidence."
      }
    ],
    "sources": [
      "CH32S89",
      "CH32S90",
      "CH32S92",
      "CH32S93",
      "CH32S94",
      "CH32S95"
    ],
    "logline": "Heart failure: contraction versus filling: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "Two matching ventricular cutaways establish the contraction and filling comparisons.",
      "One ventricle contracts weakly and retains more blood after the beat.",
      "The second ventricular wall remains stiff and accepts less filling; separate arrows track in and out.",
      "Pulmonary and systemic venous beds show distinct sites of congestion."
    ],
    "audio": "e4-ch32.m4a",
    "figures": [
      {
        "title": "Internal anatomy of the heart",
        "credit": "OpenStax College, Anatomy and Physiology (2013)",
        "url": "https://commons.wikimedia.org/wiki/File:2008_Internal_Anatomy_of_the_HeartN.jpg"
      }
    ]
  },
  {
    "id": "e4-ch33",
    "ch": 33,
    "title": "VSD: a septal opening changes pulmonary flow",
    "exam": 4,
    "duration": 67.92,
    "stages": [
      {
        "start": 0,
        "title": "Normal separation",
        "text": "The CDC figure compares a normal heart with a ventricular septal defect. The ventricular septum normally separates the two lower chambers. This institutional artwork is used for visualization, with no CDC endorsement of this study lab."
      },
      {
        "start": 15.74,
        "title": "Left to right",
        "text": "A ventricular septal defect leaves a communication. In the supplied postnatal pattern, higher left ventricular pressure sends additional blood toward the right ventricle and pulmonary circulation. Watch the added stream cross the septum."
      },
      {
        "start": 29.28,
        "title": "Pulmonary burden",
        "text": "A large shunt increases pulmonary flow. The chapter lists overcirculation and heart failure among possible consequences. This mechanism differs from an outflow obstruction or parallel circuits."
      },
      {
        "start": 41.54,
        "title": "Growth and source limits",
        "text": "Pediatric heart failure can cause poor feeding, sweating and inadequate growth. Nutritional support addresses the growth problem; medication and corrective procedures address their stated targets. Chapter thirty three, slides nine, ten and thirty through thirty two, support these points. Shifted released answer labels are marked separately. Complete murmur mapping and criteria for later cyanosis remain source gaps."
      }
    ],
    "sources": [
      "CH33S9",
      "CH33S10",
      "CH33S30",
      "CH33S31",
      "CH33S32"
    ],
    "logline": "VSD: a septal opening changes pulmonary flow: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "Normal and VSD heart cutaways sit side by side with the ventricular septa clearly visible.",
      "The VSD stream crosses from anatomical left ventricle to right ventricle.",
      "Extra pulmonary flow travels from the right ventricular outflow toward the lung bed.",
      "The shunt mechanism remains visible while the growth consequence is summarized below."
    ],
    "audio": "e4-ch33.m4a",
    "figures": [
      {
        "title": "Normal heart and ventricular septal defect",
        "credit": "CDC, National Center on Birth Defects and Developmental Disabilities",
        "url": "https://www.cdc.gov/heart-defects/about/ventricular-septal-defect.html"
      }
    ]
  }
];
