window.FILMS=[
  {
    "id": "e6-ch40",
    "ch": 40,
    "title": "Mixing and propulsion",
    "exam": 6,
    "duration": 40.68,
    "stages": [
      {
        "start": 0,
        "title": "Mixing",
        "text": "Digestion needs both mixing and forward movement. In the small intestine, segmentation uses localized rhythmic contractions to divide and mix chyme against the absorbing surface. Watch neighboring sections narrow and relax while the contents remain in the same region."
      },
      {
        "start": 16.82,
        "title": "Propulsion",
        "text": "Peristalsis serves a different purpose. A coordinated contraction wave moves the contents onward. Now the narrowing travels, and the bolus advances ahead of it."
      },
      {
        "start": 26.68,
        "title": "Compare",
        "text": "Mixing improves contact; propulsion changes location. This distinction comes from Chapter forty, slide forty-six. The illustrated timing and motion are schematic. The source does not supply a complete motor-control pathway."
      }
    ],
    "sources": [
      "CH40S46"
    ],
    "logline": "Mixing and propulsion: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "Alternating neighboring contractions divide and mix chyme with no net propulsive travel.",
      "A single constriction wave travels along the intestinal tube and moves a bolus forward.",
      "Two aligned intestinal cutaways compare local mixing with forward propulsion."
    ],
    "audio": "e6-ch40.m4a",
    "figures": [
      {
        "title": "2404 PeristalsisN",
        "credit": "OpenStax College · Anatomy & Physiology, 2013 collection 11496 v1.6 · CC BY 3.0. Source wall and bolus crops; traveling row deformation and added chyme particles.",
        "url": "https://commons.wikimedia.org/wiki/File:2404_PeristalsisN.jpg"
      }
    ]
  },
  {
    "id": "e6-ch41",
    "ch": 41,
    "title": "When intestinal flow stops",
    "exam": 6,
    "duration": 46.296,
    "stages": [
      {
        "start": 0,
        "title": "Normal movement",
        "text": "Intestinal contents normally move along the lumen. Here, the moving contraction advances material through an open segment."
      },
      {
        "start": 8.04,
        "title": "Mechanical obstruction",
        "text": "A mechanical obstruction places a lesion in that route. Incoming contents collect upstream. Watch the proximal segment expand while material fails to pass the narrowed region. Chapter forty-one explains that a lower small-bowel obstruction can produce more distention because a greater length of bowel lies upstream."
      },
      {
        "start": 26.98,
        "title": "Functional failure",
        "text": "Paralytic ileus is different. The packet describes failure of motility, especially after surgery, without an obstructing lesion. The lumen remains open, but the propulsive wave stops. The animation compares these mechanisms schematically; its dimensions do not represent a patient or a clinical threshold."
      }
    ],
    "sources": [
      "CH41S33",
      "CH41S36",
      "CH41S37"
    ],
    "logline": "When intestinal flow stops: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A contraction wave moves a bolus along an open intestinal lumen.",
      "A fixed obstruction blocks passage; proximal contents collect and the tube distends.",
      "A separate open-lumen example loses the contraction wave and contents stop advancing."
    ],
    "audio": "e6-ch41.m4a",
    "figures": [
      {
        "title": "2404 PeristalsisN",
        "credit": "OpenStax College · Anatomy & Physiology, 2013 collection 11496 v1.6 · CC BY 3.0. Source wall crop; traveling contraction, schematic blocking lesion and proximal accumulation; open immobile lumen comparison.",
        "url": "https://commons.wikimedia.org/wiki/File:2404_PeristalsisN.jpg"
      }
    ]
  },
  {
    "id": "e6-ch42",
    "ch": 42,
    "title": "Celiac injury and absorptive surface",
    "exam": 6,
    "duration": 47.016,
    "stages": [
      {
        "start": 0,
        "title": "Villus surface",
        "text": "The small intestine presents an extensive epithelial surface to the lumen. These projecting villi provide the geometry needed to understand the course packet’s celiac disease explanation."
      },
      {
        "start": 11.66,
        "title": "Immune injury",
        "text": "In the supplied mechanism, gluten ingestion triggers immune injury to the villous epithelium. T-cell infiltration accompanies inflammation and mucosal destruction. Watch the projections shorten and flatten. The loss of surface connects tissue injury with impaired absorption."
      },
      {
        "start": 27.86,
        "title": "Healing distinction",
        "text": "The packet calls for permanent gluten exclusion. It separately permits lactose reintroduction after villous healing. These are different instructions: recovery does not end gluten avoidance. This schematic deformation shows a mechanism, not a measured healing time or a diagnostic biopsy."
      }
    ],
    "sources": [
      "CH42S37",
      "CH42S40",
      "CH42S41"
    ],
    "logline": "Celiac injury and absorptive surface: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A large intestinal-wall cutaway presents tall villi with epithelial cells and internal vessels.",
      "Inflammatory cells arrive; villi shorten and flatten while the available surface falls.",
      "A separately labeled healing state restores projections without implying that gluten avoidance ends."
    ],
    "audio": "e6-ch42.m4a",
    "figures": [
      {
        "title": "2418 Histology Small IntestinesN",
        "credit": "OpenStax College · Anatomy & Physiology, 2013 collection 11496 v1.6 · CC BY 3.0. Original micrograph rotated and progressively compressed to illustrate villous flattening; partial geometric recovery is schematic.",
        "url": "https://commons.wikimedia.org/wiki/File:2418_Histology_Small_IntestinesN.jpg"
      }
    ]
  },
  {
    "id": "e6-ch43",
    "ch": 43,
    "title": "From calcium release to relaxation",
    "exam": 6,
    "duration": 47.04,
    "stages": [
      {
        "start": 0,
        "title": "Excitation and coupling",
        "text": "Muscle contraction begins with electrical excitation. The supplied sequence reaches voltage-sensitive receptors in the transverse tubules and opens ryanodine channels. Released calcium enables actin to bind myosin."
      },
      {
        "start": 13.72,
        "title": "Filament sliding",
        "text": "Now watch thin filaments move inward relative to thick filaments. Their overlap increases and the sarcomere shortens. The motion represents cross-bridge activity, not shortening of the individual filaments. The packet identifies a continuing requirement for ATP and phosphocreatine."
      },
      {
        "start": 31.14,
        "title": "Relaxation",
        "text": "During relaxation, calcium returns to the sarcoplasmic reticulum, cross-bridges detach, and the sarcomere lengthens. Follow the reverse motion. This film uses a textbook figure with schematic motion to separate excitation, coupling, contraction, and relaxation."
      }
    ],
    "sources": [
      "CH43S53",
      "CH43S54",
      "CH43S55",
      "CH43S56"
    ],
    "logline": "From calcium release to relaxation: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A T-tubule/SR inset releases calcium onto a large sarcomere.",
      "Actin slides toward the center, myosin heads cycle, and Z discs move inward; filament lengths stay fixed.",
      "Calcium returns to the SR, cross-bridges release, and the Z discs separate."
    ],
    "audio": "e6-ch43.m4a",
    "figures": [
      {
        "title": "1006 Sliding Filament Model of Muscle Contraction",
        "credit": "OpenStax · Anatomy & Physiology, 2016 v8.25 · CC BY 4.0. Thin and thick filament pixels separated by color, with thin-filament translation preserving length; calcium dots and span marker added.",
        "url": "https://commons.wikimedia.org/wiki/File:1006_Sliding_Filament_Model_of_Muscle_Contraction.jpg"
      }
    ]
  },
  {
    "id": "e6-ch44",
    "ch": 44,
    "title": "Bone loss and structural integrity",
    "exam": 6,
    "duration": 52.536,
    "stages": [
      {
        "start": 0,
        "title": "Bone architecture",
        "text": "Bone strength depends on its supporting architecture. This OpenStax figure provides a view of the trabecular network. It is a structural reference, not a patient specimen from this course."
      },
      {
        "start": 11.28,
        "title": "Resorption imbalance",
        "text": "Chapter forty-four describes osteoporosis as reduced bone mass with an imbalance between resorption and formation. Watch the supporting connections thin in this schematic adaptation. The supplied glucocorticoid pathway increases RANK ligand and inhibits osteoprotegerin, favoring lower bone density."
      },
      {
        "start": 30.7,
        "title": "Distinguish the defect",
        "text": "Less supporting bone means less structural integrity. Keep that concept separate from inadequate mineralization of osteoid in osteomalacia. The osteoporosis slides contain conflicting mineralization wording, so this film follows the explicit reduced-mass description on slide thirty-three. The amount and speed of bone loss shown are illustrative."
      }
    ],
    "sources": [
      "CH44S31",
      "CH44S32",
      "CH44S33"
    ],
    "logline": "Bone loss and structural integrity: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A porous trabecular cutaway fills the scene with connected bone struts and visible marrow spaces.",
      "Resorption thins struts and removes selected connections, opening larger spaces.",
      "A separate mineralization comparison retains the distinction between less bone and poorly mineralized osteoid."
    ],
    "audio": "e6-ch44.m4a",
    "figures": [
      {
        "title": "606 Spongy Bone",
        "credit": "OpenStax College · Anatomy & Physiology, 2013 collection 11496 v1.6 · CC BY 3.0. Unannotated trabecular crop; smoothly expanded marrow-space mask illustrates supporting bone removal.",
        "url": "https://commons.wikimedia.org/wiki/File:606_Spongy_Bone.jpg"
      }
    ]
  },
  {
    "id": "e6-ch45",
    "ch": 45,
    "title": "Femoral-head injury in Perthes disease",
    "exam": 6,
    "duration": 48.816,
    "stages": [
      {
        "start": 0,
        "title": "Locate the head",
        "text": "Locate the femoral head on this textbook illustration. Chapter forty-five identifies interruption of its blood supply as the initiating problem in Legg Calvé Perthes disease."
      },
      {
        "start": 10.76,
        "title": "Necrosis and collapse",
        "text": "The supplied sequence is necrosis of the ossification center, collapse, and gradual remodeling by living bone. Watch the highlighted head lose its rounded contour. This deformation illustrates the described collapse; it does not reproduce a patient radiograph or predict the final shape."
      },
      {
        "start": 28.3,
        "title": "Remodeling and containment",
        "text": "The final stage illustrates remodeling without promising a complete return to the original contour. The packet’s containment goal is to keep the ball completely within the socket, while maintaining motion. Knee pain can be part of this hip disorder. The source does not supply a precise recovery timeline for this animation."
      }
    ],
    "sources": [
      "CH45S39",
      "CH45S40"
    ],
    "logline": "Femoral-head injury in Perthes disease: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A hip cutaway establishes a rounded femoral head contained within the acetabulum.",
      "Blood supply to the head fades; the ossification center loses its round contour.",
      "Remodeling partially restores the head contour while the socket relationship and containment remain visible."
    ],
    "audio": "e6-ch45.m4a",
    "figures": [
      {
        "title": "916 Hip Joint",
        "credit": "OpenStax College · Anatomy & Physiology 2013, collection11496 v1.6 · CC BY 3.0. Frontal hip section retained with labels; localized superior-head deformation and tint illustrate collapse and partial remodeling. Adult figure is a location reference.",
        "url": "https://commons.wikimedia.org/wiki/File:916_Hip_Joint.jpg"
      }
    ]
  }
];
