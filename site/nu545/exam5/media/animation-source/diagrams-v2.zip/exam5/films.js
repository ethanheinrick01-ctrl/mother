window.FILMS=[
  {
    "id": "e5-ch34",
    "ch": 34,
    "title": "Alveoli, surfactant and exchange",
    "exam": 5,
    "duration": 50.616,
    "stages": [
      {
        "start": 0,
        "title": "Exchange surface",
        "text": "In the pulmonary system, an open alveolus provides a surface for gas exchange."
      },
      {
        "start": 5.34,
        "title": "Cell roles",
        "text": "Type one alveolar cells provide structure. Type two cells secrete surfactant."
      },
      {
        "start": 11,
        "title": "Surface tension",
        "text": "Notice the inner air surface during expiration. Surfactant lowers surface tension and helps prevent collapse."
      },
      {
        "start": 17.5,
        "title": "Deficiency and collapse",
        "text": "Without enough surfactant, alveoli can collapse and ventilation falls. This is especially important in premature infants whose lungs have not developed adequate production and secretion."
      },
      {
        "start": 28.22,
        "title": "Diffusion and perfusion",
        "text": "Now follow oxygen across the alveolar and capillary walls. Diffusion depends on a thin membrane, a large surface area, and a partial pressure gradient. Blood flow then carries oxygen toward the tissues. Ventilation, diffusion, and perfusion are related, but they are different steps. A change in one step can disrupt exchange even when the others remain intact."
      }
    ],
    "sources": [
      "CH34S14",
      "CH34S33",
      "CH34S37N",
      "CH34S40",
      "CH34S42",
      "CH36S19"
    ],
    "logline": "Alveoli, surfactant and exchange: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "An open alveolar cutaway dominates the stage; adjacent blood passes through its capillary bed.",
      "A thin type I lining and a distinct cuboidal type II cell are revealed on the same alveolar wall.",
      "Surfactant spreads along the internal air–liquid surface while the airspace remains open during expiration.",
      "A separately labeled deficient alveolus collapses; the supported alveolus remains available for comparison.",
      "Oxygen crosses the thin alveolar-capillary barrier, then travels with capillary blood."
    ],
    "audio": "e5-ch34.m4a",
    "figures": [
      {
        "title": "2310 Structures of the Respiratory Zone-a",
        "credit": "OpenStax Anatomy and Physiology (2016) · CC BY 4.0",
        "url": "https://commons.wikimedia.org/wiki/File:2310_Structures_of_the_Respiratory_Zone-a.jpg"
      }
    ]
  },
  {
    "id": "e5-ch35",
    "ch": 35,
    "title": "ARDS: injury through remodeling",
    "exam": 5,
    "duration": 57.936,
    "stages": [
      {
        "start": 0,
        "title": "Alveolar injury",
        "text": "Alveolar injury changes both the barrier and the airspace."
      },
      {
        "start": 4.16,
        "title": "Leak and collapse",
        "text": "In the exudative phase of acute respiratory distress syndrome, damage increases permeability of the alveolar and capillary membrane. Fluid crosses into the lung, and surfactant becomes inactivated. Watch the airspace shrink as fluid accumulates. Oxygen exchange is now impaired by more than a shortage of inspired air."
      },
      {
        "start": 23.8,
        "title": "Repair and proliferation",
        "text": "The next view shows repair and proliferation. The supplied chapter describes type two pneumocytes, fibroblasts, and myofibroblasts during this phase."
      },
      {
        "start": 32.86,
        "title": "Remodeling",
        "text": "In a fibrotic phase, remodeling and alveolar destruction further disrupt the exchange surface. These are source-described stages, with overlapping time ranges, not an inevitable clock for every patient."
      },
      {
        "start": 44.94,
        "title": "Airway contrast",
        "text": "Keep this process separate from bronchial asthma: asthma narrows the conducting airway through smooth muscle contraction, swelling, and mucus. ARDS damages the alveolar and capillary exchange region."
      }
    ],
    "sources": [
      "CH35S44",
      "CH35S45",
      "CH35S46",
      "CH35S47",
      "CH35S48",
      "CH35S53"
    ],
    "logline": "ARDS: injury through remodeling: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A large alveolar cross-section establishes the epithelial and capillary barrier.",
      "Fluid crosses damaged barrier gaps, accumulates in the airspace and reduces its open volume.",
      "Repair cells populate the injured wall; proliferating cells and fibroblasts are distinguished.",
      "Fibrous tissue thickens and disrupts the exchange geometry.",
      "A separate conducting-airway cutaway narrows through wall swelling, muscle contraction and mucus."
    ],
    "audio": "e5-ch35.m4a",
    "figures": [
      {
        "title": "2310 Structures of the Respiratory Zone-a",
        "credit": "OpenStax Anatomy and Physiology (2016) · CC BY 4.0",
        "url": "https://commons.wikimedia.org/wiki/File:2310_Structures_of_the_Respiratory_Zone-a.jpg"
      }
    ]
  },
  {
    "id": "e5-ch36",
    "ch": 36,
    "title": "CF: dehydration and impaired clearance",
    "exam": 5,
    "duration": 60.312,
    "stages": [
      {
        "start": 0,
        "title": "Ion transport",
        "text": "In cystic fibrosis, the airway problem begins with abnormal epithelial ion transport. The supplied chapter describes defective chloride transport and exaggerated sodium absorption, which deplete airway surface liquid."
      },
      {
        "start": 13.82,
        "title": "Impaired clearance",
        "text": "Watch the mucus layer lose water and become harder to move. Cilia cannot clear the adherent secretions effectively, and bacteria remain in the airway."
      },
      {
        "start": 22.86,
        "title": "Inflammation and viscosity",
        "text": "Inflammation then amplifies the problem. Degraded neutrophils release DNA and filamentous actin, adding to mucus viscosity."
      },
      {
        "start": 31.3,
        "title": "Structural injury",
        "text": "Thick secretions obstruct small airways, while chronic inflammation can lead to bronchiectasis and fibrosis. The drawing shows a mechanism, not a scaled measurement of mucus thickness or a prediction for an individual child."
      },
      {
        "start": 45.12,
        "title": "Newborn RDS contrast",
        "text": "Distinguish this process from newborn respiratory distress syndrome. In that disorder, inadequate surfactant in the immature lung promotes alveolar collapse. Both can impair breathing, but the initiating defect and the affected surface are different."
      }
    ],
    "sources": [
      "CH36S40",
      "CH36S42",
      "CH36S43",
      "CH36S47N",
      "CH36S19"
    ],
    "logline": "CF: dehydration and impaired clearance: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A ciliated epithelial sheet shows chloride transport failure, sodium uptake and decreasing surface liquid.",
      "The watery layer thins; thick mucus adheres and cilia move ineffectively underneath.",
      "Inflammatory cells add visible DNA/actin strands to the viscous layer.",
      "A separate airway cross-section shows obstruction and remodeled walls.",
      "A distinct alveolar comparison demonstrates surfactant deficiency and collapse."
    ],
    "audio": "e5-ch36.m4a",
    "figures": [
      {
        "title": "2311 Lung Tissue",
        "credit": "OpenStax College (2013) · CC BY 3.0",
        "url": "https://commons.wikimedia.org/wiki/File:2311_Lung_Tissue.jpg"
      }
    ]
  },
  {
    "id": "e5-ch37",
    "ch": 37,
    "title": "Countercurrent concentration and ADH",
    "exam": 5,
    "duration": 55.848,
    "stages": [
      {
        "start": 0,
        "title": "Opposite limbs",
        "text": "Follow the filtrate through the loop of Henle. Its two limbs run beside each other, but they do not handle water and solute in the same way."
      },
      {
        "start": 8.38,
        "title": "Build the gradient",
        "text": "The supplied chapter describes active sodium and chloride transport from the thick ascending limb into the medullary interstitium. This helps create a concentrated environment around the loop."
      },
      {
        "start": 21.22,
        "title": "Descending water loss",
        "text": "Water can then leave the water-permeable descending limb, concentrating the fluid that remains inside."
      },
      {
        "start": 27.32,
        "title": "Ascending dilution",
        "text": "In the ascending limb, solute leaves while water is retained, so the tubular fluid becomes more dilute."
      },
      {
        "start": 33.9,
        "title": "Final ADH adjustment",
        "text": "Finally, follow the fluid toward the collecting duct. Antidiuretic hormone increases water permeability there. More water returns to the body, and final urine volume decreases. Keep the two ideas separate: the loop builds the concentration gradient, while antidiuretic hormone regulates the final water adjustment. Motion, colors, and quantities are schematic."
      }
    ],
    "sources": [
      "CH37S45",
      "CH37S46",
      "CH37S52",
      "CH37S53",
      "CH37S55"
    ],
    "logline": "Countercurrent concentration and ADH: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A continuous U-shaped loop establishes descending and ascending directions beside a collecting duct.",
      "Salt leaves the thick ascending limb and builds a deeper medullary gradient.",
      "Water exits the descending limb while luminal solute concentration increases.",
      "Salt exits the ascending limb while water remains; its luminal color becomes dilute.",
      "The collecting duct gains water channels and water crosses into the surrounding tissue/blood."
    ],
    "audio": "e5-ch37.m4a",
    "figures": [
      {
        "title": "2618 Nephron Secretion Reabsorption",
        "credit": "OpenStax College (2013) · CC BY 3.0",
        "url": "https://commons.wikimedia.org/wiki/File:2618_Nephron_Secretion_Reabsorption.jpg"
      }
    ]
  },
  {
    "id": "e5-ch38",
    "ch": 38,
    "title": "Obstruction, dilation and relief",
    "exam": 5,
    "duration": 56.16,
    "stages": [
      {
        "start": 0,
        "title": "Normal outflow",
        "text": "An obstruction changes what happens upstream. In this urinary tract illustration, urine normally moves from the renal pelvis through the ureter toward the bladder."
      },
      {
        "start": 9.5,
        "title": "Obstruction",
        "text": "Now a narrowing interrupts that outflow. The supplied chapter distinguishes hydroureter, dilation of the ureter, from hydronephrosis, dilation of the renal pelvis and calyces."
      },
      {
        "start": 20.26,
        "title": "Upstream dilation",
        "text": "Watch the collecting spaces expand upstream of the obstruction. Severity depends on its location, completeness, duration, and whether one or both upper tracts are involved. Prolonged damage can produce fibrosis and loss of nephrons."
      },
      {
        "start": 35.26,
        "title": "Relief and diuresis",
        "text": "When obstruction is relieved, increased urine output may follow. The chapter calls this postobstructive diuresis and warns of fluid and electrolyte imbalance."
      },
      {
        "start": 45.34,
        "title": "Unresolved scope",
        "text": "This film does not supply the missing explanation of how unilateral obstruction causes hypertension. That requested guide component remains explicitly marked as a textbook gap."
      }
    ],
    "sources": [
      "CH37S9",
      "CH37S22",
      "CH38S7",
      "CH38S8",
      "CH38S9"
    ],
    "logline": "Obstruction, dilation and relief: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A kidney cutaway, renal pelvis, ureter and bladder carry urine downward.",
      "A focal narrowing blocks the ureter; movement stops above it.",
      "The ureter, pelvis and calyces expand upstream, with preserved cortex orientation.",
      "The narrowing releases and an increased stream travels down the ureter.",
      "The anatomy holds with the unsupported hypertension mechanism explicitly excluded."
    ],
    "audio": "e5-ch38.m4a",
    "figures": [
      {
        "title": "2610 The Kidney",
        "credit": "OpenStax College (2013) · CC BY 3.0",
        "url": "https://commons.wikimedia.org/wiki/File:2610_The_Kidney.jpg"
      }
    ]
  },
  {
    "id": "e5-ch39",
    "ch": 39,
    "title": "Reflux: reverse flow and infection",
    "exam": 5,
    "duration": 56.184,
    "stages": [
      {
        "start": 0,
        "title": "Identify the junction",
        "text": "Vesicoureteral reflux reverses the normal direction of urinary flow. Begin at the bladder and identify where each ureter enters."
      },
      {
        "start": 8.84,
        "title": "Normal protection",
        "text": "The normal junction helps prevent urine from moving backward during bladder emptying."
      },
      {
        "start": 13.24,
        "title": "Retrograde flow",
        "text": "In reflux, a congenital junction abnormality or abnormal ureteral insertion can allow urine to travel back toward the ureter and kidney. Watch the direction change along the same anatomy."
      },
      {
        "start": 25.37,
        "title": "Ascending infection",
        "text": "When the bladder urine is infected, reflux can carry that infection upward and encourage repeated pyelonephritis."
      },
      {
        "start": 32.87,
        "title": "Findings and limits",
        "text": "The supplied chapter describes silent cases as well as recurrent urinary infections, unexplained fever, and poor growth. It lists prompt treatment of infection and intervention for recurrent or high-grade reflux. This visualization shows the direction and consequence of reflux. It does not invent the missing grade-by-grade criteria, and its flow speed and volume are schematic."
      }
    ],
    "sources": [
      "CH37S22",
      "CH38S30",
      "CH39S39",
      "CH39S40"
    ],
    "logline": "Reflux: reverse flow and infection: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A bladder cutaway shows both oblique ureteral entries and the outlet.",
      "During emptying the junctions close against backward flow while urine exits downward.",
      "A separate reflux comparison opens one incompetent junction and reverses the stream up that ureter.",
      "Infected-urine markers follow the retrograde route toward the kidney.",
      "The abnormal route remains legible with no invented reflux grades."
    ],
    "audio": "e5-ch39.m4a",
    "figures": [
      {
        "title": "2605 The Bladder, illustration panel (a)",
        "credit": "OpenStax College (2013) · CC BY 3.0",
        "url": "https://commons.wikimedia.org/wiki/File:2605_The_Bladder.jpg"
      }
    ]
  }
];
