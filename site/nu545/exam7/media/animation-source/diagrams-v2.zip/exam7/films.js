window.FILMS=[
  {
    "id": "e7-ch4",
    "ch": 4,
    "title": "Transcription: making the message",
    "exam": 7,
    "duration": 26.184,
    "stages": [
      {
        "start": 0,
        "title": "Template",
        "text": "Follow the DNA template. RNA polymerase binds at the promoter and builds a complementary messenger RNA strand."
      },
      {
        "start": 7.18,
        "title": "Message",
        "text": "Watch the RNA message lengthen and leave the template. This is transcription. The DNA sequence provides the information; the RNA carries a copy."
      },
      {
        "start": 15.92,
        "title": "Next step",
        "text": "Translation comes next at a ribosome. Transfer RNA matches messenger codons while a polypeptide is assembled. Do not confuse message production with protein assembly."
      }
    ],
    "sources": [
      "C4S12",
      "C4S13"
    ],
    "logline": "Transcription: making the message: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A DNA helix opens around a polymerase, revealing the template strand.",
      "A complementary RNA strand grows behind the moving polymerase and separates from the DNA.",
      "The RNA enters a separate ribosome where tRNA brings amino acids and the chain lengthens."
    ],
    "audio": "e7-ch4.m4a",
    "figures": [
      {
        "title": "DNA transcription",
        "credit": "NHGRI; vector adaptation by Sulai (2009) · public domain · original unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:DNA_transcription.svg"
      }
    ]
  },
  {
    "id": "e7-ch5",
    "ch": 5,
    "title": "Insulin: response and supply",
    "exam": 7,
    "duration": 31.104,
    "stages": [
      {
        "start": 0,
        "title": "Insulin resistance",
        "text": "Chapter five. Obesity is a risk factor for type two diabetes, but the connection is more than a label. The supplied notes describe insulin resistance: cells have difficulty using the insulin present."
      },
      {
        "start": 13.06,
        "title": "Supply contrast",
        "text": "Watch the tissue response weaken while insulin remains available. Contrast this with type one diabetes, where autoimmune destruction reduces the pancreatic beta-cell supply."
      },
      {
        "start": 23.28,
        "title": "Modifiable risk",
        "text": "Family history also changes risk. Exercise and weight management address modifiable contributors; they do not erase inherited susceptibility."
      }
    ],
    "sources": [
      "C5S26",
      "C5S28",
      "C5S30N"
    ],
    "logline": "Insulin: response and supply: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "Insulin reaches a tissue-cell membrane while reduced response limits glucose entry.",
      "A separate pancreatic-islet comparison reduces insulin supply through beta-cell loss.",
      "The distinct supply and response models hold while modifiable versus inherited risk is stated below."
    ],
    "audio": "e7-ch5.m4a",
    "figures": [
      {
        "title": "Homeostatic regulation of glucose",
        "credit": "OpenStax College, Anatomy & Physiology (2013) · CC BY 3.0 · original unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:1822_The_Homostatic_Regulation_of_Blood_Glucose_Levels.jpg"
      }
    ]
  },
  {
    "id": "e7-ch6",
    "ch": 6,
    "title": "Epigenetics: changing access",
    "exam": 7,
    "duration": 27.024,
    "stages": [
      {
        "start": 0,
        "title": "Chromatin",
        "text": "DNA wraps around histone proteins. Tight packing is heterochromatin; loose packing is euchromatin."
      },
      {
        "start": 7.38,
        "title": "Silencing",
        "text": "Now add methyl groups at a promoter. The supplied cancer example links heavy promoter methylation with reduced tumor-suppressor transcription. The base sequence need not change."
      },
      {
        "start": 18.16,
        "title": "Different outcomes",
        "text": "A chemical modification can change gene activity. Different expression patterns help cells acquire different identities, even when they carry the same DNA."
      }
    ],
    "sources": [
      "C6S4",
      "C6S6",
      "C6S10",
      "C6S26"
    ],
    "logline": "Epigenetics: changing access: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "DNA wraps around histone cores; spaced and tightly packed chromatin are compared.",
      "Methyl groups appear at a promoter and polymerase access/transcription decreases without changing the DNA sequence.",
      "Two cell states show different expression output from a matching DNA sequence."
    ],
    "audio": "e7-ch6.m4a",
    "figures": [
      {
        "title": "Epigenetic mechanisms",
        "credit": "NIH (2005) · public domain · original unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:Epigenetic_mechanisms.png"
      }
    ]
  },
  {
    "id": "e7-ch12",
    "ch": 12,
    "title": "Invasion: crossing a tissue boundary",
    "exam": 7,
    "duration": 28.728,
    "stages": [
      {
        "start": 0,
        "title": "Boundary",
        "text": "A tumor can enlarge without yet establishing a distant deposit. First examine its boundary with surrounding tissue."
      },
      {
        "start": 6.94,
        "title": "Invasion",
        "text": "Watch protease activity open a path through extracellular matrix and basement membrane. Reduced adhesion and increased migration help cells leave the original site."
      },
      {
        "start": 17.28,
        "title": "Metastasis",
        "text": "Entry into blood or lymph is not enough. Cells must survive transport and grow in a receptive distant environment. Local invasion and successful metastasis are separate steps."
      }
    ],
    "sources": [
      "C12S38",
      "C12S39",
      "C12S40",
      "C12S41"
    ],
    "logline": "Invasion: crossing a tissue boundary: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A tissue cross-section shows a tumor bounded by basement membrane and extracellular matrix.",
      "Protease-associated gaps open; individual cells separate and migrate across the boundary.",
      "A distinct vessel-to-distant-tissue view separates transport from successful growth at a new site."
    ],
    "audio": "e7-ch12.m4a",
    "figures": [
      {
        "title": "Ductal carcinoma in situ",
        "credit": "NCI / Don Bliss (2005) · public domain · original unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:Breast_cancer_ductal_carcinoma_in_situ.jpg"
      }
    ]
  },
  {
    "id": "e7-ch13",
    "ch": 13,
    "title": "Adipose tissue and cancer risk",
    "exam": 7,
    "duration": 27.528,
    "stages": [
      {
        "start": 0,
        "title": "Active tissue",
        "text": "Adipose tissue is an active participant in the cancer-risk model. It releases adipokines."
      },
      {
        "start": 6,
        "title": "Interacting pathways",
        "text": "With obesity, the supplied deck links insulin resistance and hyperinsulinemia. Watch signaling increase around the tissue. This is a risk mechanism, not proof that a tumor will develop."
      },
      {
        "start": 18.1,
        "title": "Activity",
        "text": "Physical activity can reduce inflammatory mediators and insulin-like growth factors. The packet describes protection for selected cancers even without weight loss."
      }
    ],
    "sources": [
      "C13S14",
      "C13S17"
    ],
    "logline": "Adipose tissue and cancer risk: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "An adipocyte tissue section releases visible adipokine signals.",
      "Insulin-related signaling increases around the same cells without producing an inevitable tumor.",
      "The inflammatory/IGF signal field diminishes while the tissue remains present."
    ],
    "audio": "e7-ch13.m4a",
    "figures": [
      {
        "title": "Adipose tissue",
        "credit": "OpenStax College, Anatomy & Physiology (2013) · CC BY 3.0 · original unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:409_Adipose_Tissue.jpg"
      }
    ]
  },
  {
    "id": "e7-ch14",
    "ch": 14,
    "title": "Immature tissue and differentiation",
    "exam": 7,
    "duration": 29.328,
    "stages": [
      {
        "start": 0,
        "title": "Development",
        "text": "Childhood cancer is not simply adult cancer occurring earlier. The supplied chapter emphasizes immature tissues and developmental origins."
      },
      {
        "start": 8.72,
        "title": "Diverging states",
        "text": "Compare two paths. In one, immature cells mature and differentiate. In the embryonal-tumor model, tissue fails to differentiate and retains an immature pattern."
      },
      {
        "start": 18.9,
        "title": "Scope",
        "text": "Many childhood cancers arise from mesodermal tissues. Growth timing, inherited factors and exposures belong to the same assessment; no single factor explains every case."
      }
    ],
    "sources": [
      "C14S4",
      "C14S6",
      "C14S8"
    ],
    "logline": "Immature tissue and differentiation: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A cluster of immature cells establishes the developmental starting state.",
      "Two separate branches show cells differentiating versus retaining an immature pattern.",
      "Both branches hold, preserving the distinction without assigning a universal cause."
    ],
    "audio": "e7-ch14.m4a",
    "figures": [
      {
        "title": "Stem-cell differentiation",
        "credit": "OpenStax Anatomy & Physiology v8.25 (2016) · CC BY 4.0 · original unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:422_Feature_Stem_Cell.jpg"
      }
    ]
  },
  {
    "id": "e7-ch46",
    "ch": 46,
    "title": "Pressure: from compression to ischemia",
    "exam": 7,
    "duration": 28.656,
    "stages": [
      {
        "start": 0,
        "title": "Compression",
        "text": "Pressure over a bony prominence can compress the local capillary bed. Watch flow diminish as the tissue is compressed."
      },
      {
        "start": 7.58,
        "title": "Ischemia",
        "text": "Unrelieved pressure reduces oxygen delivery and can cause ischemia and necrosis. Depth matters: injury can extend from skin into deeper supporting tissues."
      },
      {
        "start": 17.42,
        "title": "Relief",
        "text": "Pressure relief and repositioning address the initiating force. An intact red surface and an exposed deep wound represent different findings; a covered wound base may prevent staging."
      }
    ],
    "sources": [
      "C46S27",
      "C46S28",
      "C46S29",
      "C46S30"
    ],
    "logline": "Pressure: from compression to ischemia: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "An overlying force compresses skin and the capillary bed against a bony prominence.",
      "The narrowed capillaries lose flow and deeper tissue develops an ischemic color change.",
      "Pressure is removed and the compressed tissue relaxes; pre-existing injury remains distinguished from recovered flow."
    ],
    "audio": "e7-ch46.m4a",
    "figures": [
      {
        "title": "Structure of skin",
        "credit": "OpenStax College, Anatomy & Physiology (2013) · CC BY 3.0 · original unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:501_Structure_of_the_skin.jpg"
      }
    ]
  },
  {
    "id": "e7-ch47",
    "ch": 47,
    "title": "The itch and barrier cycle",
    "exam": 7,
    "duration": 29.04,
    "stages": [
      {
        "start": 0,
        "title": "Barrier",
        "text": "Atopic dermatitis involves epidermal barrier dysfunction and immune dysregulation. Filaggrin alteration is one supplied barrier mechanism."
      },
      {
        "start": 9.26,
        "title": "Scratching",
        "text": "Severe itching drives scratching. Watch the surface become disrupted, followed by a thickened epidermis with repeated scratching. The thickening is lichenification."
      },
      {
        "start": 18.3,
        "title": "Care",
        "text": "Hydration and emollients support barrier care. Distribution changes with age: infants often have face and extensor lesions, while older children favor flexures."
      }
    ],
    "sources": [
      "C47S9",
      "C47S10",
      "C47S11"
    ],
    "logline": "The itch and barrier cycle: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A skin cross-section shows gaps in the epidermal barrier.",
      "Surface abrasion develops, followed by a thicker epidermis in a repeated-scratching comparison.",
      "A surface emollient layer supports the barrier; age-related distribution remains a text distinction."
    ],
    "audio": "e7-ch47.m4a",
    "figures": [
      {
        "title": "Structure of skin",
        "credit": "OpenStax College, Anatomy & Physiology (2013) · CC BY 3.0 · original unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:501_Structure_of_the_skin.jpg"
      }
    ]
  },
  {
    "id": "e7-ch48",
    "ch": 48,
    "title": "Burns: edema with volume depletion",
    "exam": 7,
    "duration": 28.488,
    "stages": [
      {
        "start": 0,
        "title": "Leak",
        "text": "After a major burn, fluid shifts out of the circulation and tissue edema develops. Watch fluid collect outside the vessel while the circulating supply falls."
      },
      {
        "start": 10.04,
        "title": "Replacement",
        "text": "Visible swelling does not prove adequate blood volume. Fluid replacement supports the circulation; increasing capillary permeability is not its purpose."
      },
      {
        "start": 19.74,
        "title": "Monitoring",
        "text": "The supplied deck identifies urine output as the most reliable resuscitation measure. Capillary seal marks the end of burn shock in this source."
      }
    ],
    "sources": [
      "C48S46",
      "C48S47",
      "C48S48",
      "C48S54"
    ],
    "logline": "Burns: edema with volume depletion: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A capillary becomes leaky; extravascular fluid accumulates as circulating volume drops.",
      "A replacement stream replenishes intravascular fluid without increasing the leak.",
      "The vascular response holds beside a schematic urine-output monitor; the barrier begins to seal."
    ],
    "audio": "e7-ch48.m4a",
    "figures": [
      {
        "title": "Lymphatic system with blood-capillary inset",
        "credit": "OpenStax College, Anatomy & Physiology (2013) · CC BY 3.0 · original unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:2201_Anatomy_of_the_Lymphatic_System.jpg"
      }
    ]
  },
  {
    "id": "e7-ch49",
    "ch": 49,
    "title": "Perfusion before pressure falls",
    "exam": 7,
    "duration": 26.376,
    "stages": [
      {
        "start": 0,
        "title": "Early shock",
        "text": "A child can have poor tissue perfusion while systolic pressure remains appropriate for age. This is compensated shock."
      },
      {
        "start": 7.6,
        "title": "Redistribution",
        "text": "Watch peripheral flow decrease as blood is redistributed. A normal pressure reading does not erase abnormal perfusion findings."
      },
      {
        "start": 14.7,
        "title": "Deterioration",
        "text": "Hypotension marks a later category. Bradycardia in a severely ill child can signal deterioration, and hypoxia is a common cause. Assess oxygen delivery and perfusion together."
      }
    ],
    "sources": [
      "C49S5",
      "C49S6",
      "C49S17",
      "C49S18",
      "C49S25",
      "C49S26"
    ],
    "logline": "Perfusion before pressure falls: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A branching vascular bed shows reduced tissue delivery alongside maintained pressure.",
      "Peripheral branches constrict and carry less flow while central perfusion is favored.",
      "A separately identified later state loses pressure and slows the pulse; oxygen delivery remains visible."
    ],
    "audio": "e7-ch49.m4a",
    "figures": [
      {
        "title": "Lymphatic system with blood-capillary inset",
        "credit": "OpenStax College, Anatomy & Physiology (2013) · CC BY 3.0 · original unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:2201_Anatomy_of_the_Lymphatic_System.jpg"
      }
    ]
  }
];
