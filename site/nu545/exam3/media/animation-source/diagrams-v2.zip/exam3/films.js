window.FILMS=[
  {
    "id": "e3-ch21",
    "ch": 21,
    "title": "ADH: hormone supply, renal response, and water balance",
    "exam": 3,
    "duration": 57.833333,
    "stages": [
      {
        "start": 0,
        "title": "Stimulus and sensor",
        "text": "Higher plasma osmolality or lower circulating volume signals for ADH."
      },
      {
        "start": 12.231,
        "title": "Synthesis, storage, release",
        "text": "Synthesis occurs in the hypothalamus. Storage and release occur in the posterior pituitary."
      },
      {
        "start": 26.217,
        "title": "Water reabsorption",
        "text": "ADH increases collecting-duct water permeability. More water returns to blood."
      },
      {
        "start": 40.193,
        "title": "Two DI mechanisms",
        "text": "Neurogenic DI lacks adequate ADH. Nephrogenic DI has renal insensitivity to ADH. Both impair urine concentration."
      }
    ],
    "sources": [
      "CH21S25",
      "CH21S26",
      "CH22S14",
      "CH22S17"
    ],
    "logline": "ADH: hormone supply, renal response, and water balance: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A hypothalamus–pituitary cutaway connects to a large collecting-duct section; circulating volume and concentration change.",
      "ADH travels down the neuronal tract, collects in the posterior lobe, then enters a vessel.",
      "Water channels appear in the duct wall and water crosses toward the adjacent capillary.",
      "Two separately labeled comparisons hold: low hormone supply and poor renal response; concentrated-urine transport is reduced."
    ],
    "audio": "e3-ch21.m4a",
    "figures": [
      {
        "title": "Posterior pituitary complex",
        "credit": "OpenStax College · Anatomy & Physiology (2013) · CC BY 3.0 · original figure unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:1807_The_Posterior_Pituitary_Complex.jpg"
      },
      {
        "title": "Collecting-tubule water movement",
        "credit": "OpenStax College · Anatomy & Physiology (2013) · CC BY 3.0 · original figure unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:2710_Aquaporins-01.jpg"
      }
    ]
  },
  {
    "id": "e3-ch22",
    "ch": 22,
    "title": "Insulin: supply and tissue response",
    "exam": 3,
    "duration": 49.056,
    "stages": [
      {
        "start": 0,
        "title": "Insulin supply",
        "text": "Two different failures can raise blood glucose. Start with the pancreatic beta cells. In type one diabetes, beta cells are destroyed or lost, and insulin production falls. Watch the declining insulin supply."
      },
      {
        "start": 13.1,
        "title": "Insulin response",
        "text": "In type two diabetes, insulin resistance and decreased beta-cell secretion are the major mechanisms. The liver, muscle, and adipose tissue respond less effectively to insulin. Seeing insulin present does not prove that its effect is adequate."
      },
      {
        "start": 27.48,
        "title": "Same finding, different failure",
        "text": "Blood glucose can remain elevated in both comparisons. The common finding is hyperglycemia. The question is whether the problem is secretion, tissue response, or both."
      },
      {
        "start": 38.16,
        "title": "Keep the disorders separate",
        "text": "Keep diabetes mellitus separate from diabetes insipidus. Mellitus concerns insulin and glucose. The insipidus lesson concerns antidiuretic hormone and urine concentration."
      }
    ],
    "sources": [
      "CH22S56",
      "CH22S59",
      "CH22S65",
      "CH22S67",
      "CH22S17"
    ],
    "logline": "Insulin: supply and tissue response: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "Pancreatic islet cells diminish and fewer insulin molecules reach a tissue membrane.",
      "A separate comparison keeps insulin present while receptor response and glucose uptake weaken.",
      "Both comparisons retain glucose in their vascular compartments.",
      "The glucose model holds alongside a small, distinct water-balance comparison."
    ],
    "audio": "e3-ch22.m4a",
    "figures": [
      {
        "title": "Posterior pituitary complex",
        "credit": "OpenStax College · Anatomy & Physiology (2013) · CC BY 3.0 · original figure unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:1807_The_Posterior_Pituitary_Complex.jpg"
      },
      {
        "title": "Collecting-tubule water movement",
        "credit": "OpenStax College · Anatomy & Physiology (2013) · CC BY 3.0 · original figure unchanged",
        "url": "https://commons.wikimedia.org/wiki/File:2710_Aquaporins-01.jpg"
      },
      {
        "title": "Pancreatic tissue and insulin response",
        "credit": "OpenStax College, Anatomy & Physiology (2013), CC BY 3.0",
        "url": "https://commons.wikimedia.org/wiki/File:1822_The_Homostatic_Regulation_of_Blood_Glucose_Levels.jpg"
      }
    ]
  },
  {
    "id": "e3-ch23",
    "ch": 23,
    "title": "Adipose tissue: storage, heat, and inflammation",
    "exam": 3,
    "duration": 57.24,
    "stages": [
      {
        "start": 0,
        "title": "White adipose tissue",
        "text": "Adipose tissue is active tissue. White adipose stores excess energy as triglycerides and acts as an endocrine organ. Its adipokines participate in energy balance, insulin sensitivity, and inflammatory responses. Watch the stored fat expand within the illustrated cells."
      },
      {
        "start": 17.54,
        "title": "Brown and beige tissue",
        "text": "Brown adipose is rich in mitochondria. Cold exposure and sympathetic activation can stimulate it to generate heat through uncoupling protein one. Beige tissue can emerge within white adipose with chronic cold exposure or exercise. With warm adaptation, beige tissue can return to white adipose."
      },
      {
        "start": 35.34,
        "title": "Inflammation and insulin sensitivity",
        "text": "In obesity, macrophages infiltrate adipose tissue and inflammatory mediators are released. The supplied slides connect these changes with possible insulin resistance. More stored fat, altered endocrine signals, and inflammation belong to the same mechanism. Fat storage and heat production are different functions. Keep white, brown, and beige adipose distinct."
      }
    ],
    "sources": [
      "CH23S5",
      "CH23S6",
      "CH23S7",
      "CH23S8",
      "CH23S12"
    ],
    "logline": "Adipose tissue: storage, heat, and inflammation: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "One large adipocyte expands its lipid droplet among a field of smaller tissue cells.",
      "White, brown and beige cells are compared; multilocular brown tissue reveals mitochondria and heat output.",
      "Macrophages enter intercellular spaces and inflammatory signaling appears around adipocytes."
    ],
    "audio": "e3-ch23.m4a",
    "figures": [
      {
        "title": "Adipose tissue illustration and histology",
        "credit": "OpenStax College, Anatomy & Physiology (2013), CC BY 3.0",
        "url": "https://commons.wikimedia.org/wiki/File:409_Adipose_Tissue.jpg"
      }
    ]
  },
  {
    "id": "e3-ch24",
    "ch": 24,
    "title": "The ovarian cycle and the endometrium",
    "exam": 3,
    "duration": 57,
    "stages": [
      {
        "start": 0,
        "title": "Follicular growth",
        "text": "Follow the ovary and the uterine lining together. Rising follicle-stimulating hormone stimulates follicular growth. One follicle becomes dominant and produces increasing estradiol. Estrogen drives proliferation of the endometrium."
      },
      {
        "start": 14.5,
        "title": "Ovulation",
        "text": "The luteinizing hormone surge causes ovulation. Watch the mature follicle release the ovum. Then follow the remaining follicle as it becomes the corpus luteum."
      },
      {
        "start": 24.66,
        "title": "Secretory phase",
        "text": "Luteinizing hormone stimulates the corpus luteum to secrete progesterone. Progesterone initiates the secretory phase. Endometrial glands and blood vessels branch and curl through the functional layer."
      },
      {
        "start": 36.46,
        "title": "Without implantation",
        "text": "If implantation does not occur, the corpus luteum degenerates. Estrogen and progesterone fall, and the endometrium degenerates and sheds. The hormone sequence explains the tissue sequence: follicular growth, ovulation, secretory change, and menstruation. Estrogen supports proliferation; progesterone initiates secretion."
      }
    ],
    "sources": [
      "CH24S31",
      "CH24S32",
      "CH24S33",
      "CH24S34",
      "CH24S35",
      "CH24S36"
    ],
    "logline": "The ovarian cycle and the endometrium: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "Follicles grow in the ovarian cutaway as the endometrial functional layer thickens.",
      "The dominant follicle opens, releases an ovum, and becomes a corpus luteum.",
      "Glands coil and branch within a thicker endometrial layer while the corpus luteum persists.",
      "The corpus luteum regresses; the functional layer fragments and sheds, leaving the basal layer."
    ],
    "audio": "e3-ch24.m4a",
    "figures": [
      {
        "title": "Ovarian and uterine cycle",
        "credit": "OpenStax College, Anatomy & Physiology cycle figure, CC BY 4.0",
        "url": "https://commons.wikimedia.org/wiki/File:Figure_28_02_07.jpg"
      }
    ]
  },
  {
    "id": "e3-ch25",
    "ch": 25,
    "title": "Breast ducts: in situ and invasive disease",
    "exam": 3,
    "duration": 54.504,
    "stages": [
      {
        "start": 0,
        "title": "Find the duct",
        "text": "Start with the branching breast ducts and lobules. Now move closer to the duct wall. The basement membrane is the boundary that matters in this comparison."
      },
      {
        "start": 10.2,
        "title": "In situ disease",
        "text": "Ductal carcinoma in situ is limited to the breast ducts and lobules without invading the basement membrane. Watch abnormal cells accumulate inside the boundary. Their number can increase while that boundary remains intact."
      },
      {
        "start": 23.66,
        "title": "Invasive disease",
        "text": "Invasive carcinoma crosses into surrounding tissue. Watch cells extend beyond the duct boundary in the second comparison. These are different disease states. The supplied slides do not establish that every in situ lesion will become invasive."
      },
      {
        "start": 38.72,
        "title": "Metastatic origin",
        "text": "The released breast case then distinguishes a breast cancer deposit in the lung from a new primary lung cancer. A tumor found in the lung can still have a breast origin. Keep location, invasion, and tumor origin separate when interpreting the case."
      }
    ],
    "sources": [
      "CH24S41",
      "CH25S56",
      "CH25S66",
      "CH25S67",
      "CH25CASE4",
      "CH25CASE5"
    ],
    "logline": "Breast ducts: in situ and invasive disease: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A branching duct tree resolves into a large cylindrical duct cutaway with an intact basement membrane.",
      "Abnormal cells accumulate inside the intact duct, without crossing the boundary.",
      "A separately labeled invasive comparison shows cells crossing a breached boundary into stroma.",
      "A distinct distant-site inset shows a breast-origin cell deposit; the primary duct stays visible."
    ],
    "audio": "e3-ch25.m4a",
    "figures": [
      {
        "title": "Ductal carcinoma in situ",
        "credit": "National Cancer Institute / Don Bliss (2005), public domain",
        "url": "https://commons.wikimedia.org/wiki/File:Breast_cancer_ductal_carcinoma_in_situ.jpg"
      },
      {
        "title": "Mammary architecture within the let-down reflex plate",
        "credit": "OpenStax College, Anatomy & Physiology (2013), CC BY 3.0",
        "url": "https://commons.wikimedia.org/wiki/File:2922_Let_Down_Reflex-new.jpg"
      }
    ]
  },
  {
    "id": "e3-ch26",
    "ch": 26,
    "title": "Epididymitis: follow the site and route",
    "exam": 3,
    "duration": 54.456,
    "stages": [
      {
        "start": 0,
        "title": "Locate the structures",
        "text": "Locate the testis, epididymis, and vas deferens on the anatomical illustration. The testis produces sperm. Sperm mature in the epididymis, and the vas deferens transports them toward the urethra."
      },
      {
        "start": 12.78,
        "title": "Follow the infection route",
        "text": "For epididymitis, reverse that usual direction. The supplied slide describes a microorganism ascending the vas deferens from an infected bladder or urethra to reach the epididymis. Watch the highlighted inflammatory change develop at the epididymis."
      },
      {
        "start": 27.64,
        "title": "Distinguish the affected organ",
        "text": "Epididymitis is inflammation of the epididymis. Orchitis is infection of the testis and may occur with epididymitis. Similar pain does not make these the same affected structure."
      },
      {
        "start": 39.16,
        "title": "Study within the source limits",
        "text": "The epididymitis slide lists pain and the Prehn sign, with antibiotics, analgesics, ice, and scrotal elevation as treatments. It does not provide a complete organism or complication list. Those textbook details remain marked as gaps in this guide."
      }
    ],
    "sources": [
      "CH24S44",
      "CH24S45",
      "CH26S31",
      "CH26S28"
    ],
    "logline": "Epididymitis: follow the site and route: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A testis cutaway, coiled epididymis and continuous vas deferens carry sperm along the correct route.",
      "The travel direction reverses along the vas toward the epididymis; local tissue swells.",
      "The epididymis and testis receive separate attached callouts showing distinct affected organs.",
      "The anatomical view holds and the source-limited teaching caption stays concise."
    ],
    "audio": "e3-ch26.m4a",
    "figures": [
      {
        "title": "Testis, epididymis, and deferens anatomy",
        "credit": "OpenStax Anatomy & Physiology version 8.25 (2016), CC BY 4.0",
        "url": "https://commons.wikimedia.org/wiki/File:Figure_28_01_03.jpg"
      }
    ]
  },
  {
    "id": "e3-ch27",
    "ch": 27,
    "title": "Syphilis: local, systemic, and latent disease",
    "exam": 3,
    "duration": 59.328,
    "stages": [
      {
        "start": 0,
        "title": "Primary disease",
        "text": "Syphilis is caused by Treponema pallidum. In primary syphilis, focus on the local lesion: a firm, indurated, painless chancre, with firm, enlarged, nontender regional lymph nodes."
      },
      {
        "start": 11.54,
        "title": "Systemic spread",
        "text": "The supplied slides describe microorganisms draining with lymphatic fluid. Secondary syphilis has systemic manifestations, including low-grade fever, malaise, sore throat, generalized lymph-node enlargement, and skin or mucous-membrane lesions. Watch the local site connect with the wider lymphatic network."
      },
      {
        "start": 29.44,
        "title": "Latent and tertiary disease",
        "text": "Latent syphilis can be asymptomatic while medical evidence of infection remains. Absence of symptoms does not mean the infection has disappeared. Tertiary disease can include destructive gummas and neurosyphilis."
      },
      {
        "start": 43.54,
        "title": "The closest ulcer contrast",
        "text": "Keep the primary syphilitic chancre separate from chancroid. The supplied chancroid slide describes a painful, tender, soft chancre. Use the lesion findings and the disease stage together. This visual shows a schematic sequence, not a prediction for every patient."
      }
    ],
    "sources": [
      "CH27S16",
      "CH27S17",
      "CH27S18",
      "CH27S19",
      "CH27S22"
    ],
    "logline": "Syphilis: local, systemic, and latent disease: the changing anatomical structures make the narrated mechanism and its closest comparison visible.",
    "motion": [
      "A local skin section shows a chancre beside a regional lymphatic branch.",
      "Spiral microorganisms move through the connected lymphatic channels; additional nodes become involved.",
      "A separately labeled latent state removes visible symptom marks while microbial evidence remains.",
      "Two lesion cross-sections compare firm painless versus soft painful findings without implying inevitable progression."
    ],
    "audio": "e3-ch27.m4a",
    "figures": [
      {
        "title": "Lymphatic anatomy and capillary network",
        "credit": "OpenStax College, Anatomy & Physiology (2013), CC BY 3.0",
        "url": "https://commons.wikimedia.org/wiki/File:2201_Anatomy_of_the_Lymphatic_System.jpg"
      },
      {
        "title": "Treponema pallidum electron micrograph",
        "credit": "CDC / Dr. David Cox, PHIL 1977, public domain",
        "url": "https://commons.wikimedia.org/wiki/File:Treponema_pallidum.jpg"
      }
    ]
  }
];
